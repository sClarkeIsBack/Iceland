import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmlwdHZpY2VsYW5k')

name = b.b64decode('aVBUViBJY2VsYW5k')

host = b.b64decode('aHR0cDovL2lwYmVhY2guY29t')

port = b.b64decode('ODA=')